# cRevive

**Two legends. One language.**

cRevive is an experimental programming language inspired by C, C++, and Rust. Its syntax is being designed as a fresh language, while this repository contains three reference interpreters implemented separately in **C**, **C#**, and **Rust**.

<details>
<summary>Logo artwork</summary>

![cRevive icon](assets/crevive-icon.png)

![cRevive poster](assets/crevive-poster.png)

The standalone vector mark is in [`assets/crevive-logo.svg`](assets/crevive-logo.svg).
</details>

## What is included

- `src/c/crevive.c` — C11 reference interpreter.
- `src/csharp/` — .NET 8 C# interpreter project.
- `src/rust/` — Rust interpreter crate.
- `examples/` — runnable `.crv` programs.
- `docs/LANGUAGE_SPEC.md` — language behavior and syntax rules.
- `docs/GRAMMAR.ebnf` — first formal grammar.
- `docs/ARCHITECTURE.md` — interpreter design and compiler roadmap.
- `CHANGELOG.md` — v0.1 release notes.
- `assets/` — logo and poster artwork.

## First syntax

```crevive
import core

say "Hello, cRevive!"

Define text [greet] = (name) {
    say "Hello, " + name
    Return "done"
}

greet("developer")

Loop (3) = {
    say "looping"
}

count = 0
While loop (count < 3) {
    say count
    count = count + 1
}

Check count ** 3 {
    say "Check passed"
}

~~ This is a comment.
```

`**` is cRevive's original equality operator. `==` is accepted as an alias. `Postion` intentionally keeps the spelling from the original language proposal.

## Build and run

### C (C11)

Requires GCC or Clang.

```sh
gcc -std=c11 -O2 src/c/crevive.c -lm -o crevive
./crevive examples/hello.crv
```

### C# (.NET 8)

Requires the .NET 8 SDK.

```sh
dotnet run --project src/csharp/cRevive.csproj -- examples/hello.crv
```

### Rust

Requires Rust and Cargo.

```sh
cargo run --manifest-path src/rust/Cargo.toml -- examples/hello.crv
```

## Build helper

On Linux/macOS, `./scripts/build_available.sh` builds whichever of GCC, .NET, and Cargo are installed. It reports unavailable toolchains instead of pretending to compile them. `make test-c` compiles and checks the C interpreter against the expected output.

## v0.1 implementation status

| Feature | Status |
|---|---|
| `say`, strings and numbers | Implemented in all three interpreters |
| `import` declaration | Parsed; module loading is not implemented yet |
| `Postion` delay | Implemented |
| `Define text` and function parameters | Implemented |
| `Return` | Implemented |
| `Check` condition/null check | Implemented |
| `Loop` / `While loop` | Implemented with a 100,000-iteration safety cap |
| Variables, arithmetic and comparisons | Implemented |
| Native compiler / bytecode VM | Planned, not included in v0.1 |
| Package manager and standard library modules | Planned |

The C interpreter is the current tested reference build in this environment. The C# and Rust projects are included as corresponding implementations, but their toolchains were not available in the build environment used to assemble this archive; compile them with the commands above on machines with those SDKs installed.

## Design principles

1. Keep the user's original keywords recognizable.
2. Make grammar explicit and consistent across implementations.
3. Keep the three implementations behaviorally aligned.
4. Grow toward static types, ownership/borrowing rules, modules, diagnostics, and a native compiler in later versions.

## License

MIT. See [`LICENSE`](LICENSE).
