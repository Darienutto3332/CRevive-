# cRevive prototype architecture

The repository deliberately keeps three host-language implementations separate:

```text
cRevive source (.crv)
        |
        +--> C11 interpreter
        +--> C# / .NET interpreter
        +--> Rust interpreter
```

Each interpreter has the same basic stages:

1. **Lexer** — turns source text into identifiers, numbers, strings, symbols, newlines, and an end token. `~~` comments are discarded.
2. **Expression parser** — parses arithmetic, comparisons, equality, and boolean expressions with operator precedence.
3. **Statement evaluator** — evaluates imports, output, delays, function definitions/calls, checks, returns, loops, and assignments.
4. **Environment frames** — stores variable values and supports parent-scope lookup for function parameters.

The v0.1 implementations interpret source directly; they do not yet build a reusable AST, bytecode, or native executable. Keeping the three implementations side by side makes it possible to compare behavior as the syntax evolves.

## Planned compiler pipeline

The intended next architecture is:

```text
source -> lexer -> parser -> AST -> type checker -> intermediate representation
                                                        |
                                 +----------------------+------------------+
                                 |                      |                  |
                           C backend              C# tooling         Rust runtime
```

The backend arrangement is still a design target, not a feature claimed by v0.1.
