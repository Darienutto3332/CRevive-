# cRevive Language Specification — v0.1

## Purpose

cRevive is a small experimental language inspired by C, C++, and Rust. The language syntax is its own; C, C#, and Rust are the implementation languages used by the three reference interpreters in this repository.

## Source files

- Extension: `.crv`
- UTF-8 text
- Statements are separated by a newline outside `{ ... }` blocks.
- Blocks use braces.
- Identifiers start with a letter or `_`, followed by letters, digits, or `_`.
- Strings may use single or double quotes. `\\n`, `\\t`, `\\r`, and escaped quotes are supported.

## Core syntax

| Syntax | Meaning |
|---|---|
| `import core` | Declares a library dependency. In v0.1, imports are parsed as declarations; the built-in core functions require no import. |
| `say expression` | Prints one value followed by a newline. |
| `Postion (seconds)` | Pauses execution for a number of seconds. The spelling `Postion` is intentionally retained from the original proposal. |
| `Define text [name] = { ... }` | Defines a zero-argument function. |
| `Define text [name] = (a, b) { ... }` | Defines a function with parameters. |
| `Check expression { ... }` | Executes the block when the expression is truthy. A `null`/`nil` expression also enters the block, allowing a direct null check. |
| `Return expression` | Returns a value from the current function. |
| `Loop (count) = { ... }` | Executes the block `count` times. |
| `While loop (condition) { ... }` | Repeats while the condition is truthy. |
| `name = expression` | Creates or updates a variable in the current function scope. |
| `~~ comment` | Starts a comment that continues to the end of the line. |

## Values and operators

v0.1 includes numbers (stored as floating-point values), strings, booleans (`true`, `false`), and `null`/`nil`.

| Operator | Meaning |
|---|---|
| `**` or `==` | Equality. `**` is the original cRevive equality spelling. |
| `!=` | Inequality |
| `>` `<` `>=` `<=` | Numeric comparisons |
| `+` `-` `*` `/` `%` | Arithmetic; `+` also concatenates if either operand is a string |
| `&&` `||` `!` | Boolean logic |

Precedence follows the order in the EBNF, from logical OR (lowest) to multiplication/division/modulo (highest). Parentheses can override precedence.

## Function behavior

Functions are registered when their `Define text` statement is executed. Calls must match the declared parameter count. A function that reaches its end without `Return` produces `null`. Function parameters and assignments are held in a local frame; unresolved names can be read from the parent frame.

## Safety limits in the prototype

Both loop forms have a hard cap of 100,000 iterations to reduce the risk of an accidental infinite loop. The prototype is an interpreter, not yet a native-code compiler. `import` is currently a declaration/no-op: module loading and a package manager are planned for a later release.

## Example

```crevive
import core

Define text [greet] = (name) {
    say "Hello, " + name
    Return "done"
}

greet("world")

counter = 0
While loop (counter < 3) {
    say counter
    counter = counter + 1
}

Check counter ** 3 {
    say "The condition is true"
}
```
