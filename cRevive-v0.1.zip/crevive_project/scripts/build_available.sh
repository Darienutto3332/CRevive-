#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
status=0
if command -v gcc >/dev/null 2>&1 || command -v clang >/dev/null 2>&1; then
  cc_cmd=${CC:-$(command -v gcc || command -v clang)}
  echo "[c] Building with $cc_cmd"
  "$cc_cmd" -std=c11 -O2 src/c/crevive.c -lm -o crevive-c
else echo "[c] Skipped: GCC/Clang not installed"; status=1; fi
if command -v dotnet >/dev/null 2>&1; then
  echo "[csharp] Building with .NET"
  dotnet build src/csharp/cRevive.csproj -c Release || status=1
else echo "[csharp] Skipped: .NET SDK not installed"; status=1; fi
if command -v cargo >/dev/null 2>&1; then
  echo "[rust] Building with Cargo"
  cargo build --manifest-path src/rust/Cargo.toml --release || status=1
else echo "[rust] Skipped: Rust/Cargo not installed"; status=1; fi
exit "$status"
