/* cRevive v0.1 reference interpreter (C11)
 * Keywords: import, say, Postion, Define text, Check, Return, Loop, While loop, ~~
 */
#define _POSIX_C_SOURCE 200809L
#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define MAX_TOKENS 200000
#define MAX_FUNCS 2048
#define MAX_LOOP 100000

typedef enum { T_ID, T_NUM, T_STR, T_SYM, T_NL, T_END } TokType;
typedef struct { TokType type; char *text; int line; } Token;
typedef struct { Token *v; size_t n, cap; } TokenVec;

typedef enum { V_NULL, V_NUM, V_BOOL, V_STR } VType;
typedef struct { VType type; double number; bool boolean; char *string; } Value;
typedef struct Var { char *name; Value value; struct Var *next; } Var;
typedef struct Env { Var *vars; struct Env *parent; } Env;
typedef struct { char *name; char **params; int param_count; size_t body_start, body_end; } Function;
typedef struct { Token *tokens; size_t pos, end; Env *env; } Parser;
typedef struct { bool returned; Value value; } Flow;

static Function functions[MAX_FUNCS];
static size_t function_count = 0;
static TokenVec lexed;
static int had_error = 0;

static char *dup_n(const char *s, size_t n) { char *p = (char *)malloc(n + 1); if (!p) { perror("malloc"); exit(2); } memcpy(p, s, n); p[n] = 0; return p; }
static Value v_null(void) { Value v = {0}; v.type = V_NULL; return v; }
static Value v_num(double x) { Value v = {0}; v.type = V_NUM; v.number = x; return v; }
static Value v_bool(bool x) { Value v = {0}; v.type = V_BOOL; v.boolean = x; return v; }
static Value v_str(const char *s) { Value v = {0}; v.type = V_STR; v.string = strdup(s ? s : ""); return v; }
static bool truthy(Value v) { if (v.type == V_NULL) return false; if (v.type == V_BOOL) return v.boolean; if (v.type == V_NUM) return v.number != 0.0; if (v.type == V_STR) return v.string && v.string[0]; return false; }
static char *value_text(Value v) {
    char buf[128];
    if (v.type == V_NULL) return strdup("null");
    if (v.type == V_BOOL) return strdup(v.boolean ? "true" : "false");
    if (v.type == V_STR) return strdup(v.string ? v.string : "");
    snprintf(buf, sizeof(buf), "%.15g", v.number); return strdup(buf);
}
static void add_token(TokenVec *tv, TokType type, const char *s, size_t n, int line) {
    if (tv->n >= MAX_TOKENS) { fprintf(stderr, "cRevive: token limit exceeded\n"); exit(2); }
    if (tv->n == tv->cap) { tv->cap = tv->cap ? tv->cap * 2 : 256; tv->v = realloc(tv->v, tv->cap * sizeof(Token)); if (!tv->v) exit(2); }
    tv->v[tv->n++] = (Token){ type, dup_n(s, n), line };
}
static bool tokenize(const char *src) {
    int line = 1;
    for (size_t i = 0; src[i];) {
        char c = src[i];
        if (c == ' ' || c == '\t' || c == '\r') { i++; continue; }
        if (c == '\n') { add_token(&lexed, T_NL, "\n", 1, line++); i++; continue; }
        if (c == '~' && src[i+1] == '~') { while (src[i] && src[i] != '\n') i++; continue; }
        if (isalpha((unsigned char)c) || c == '_') { size_t st=i++; while (isalnum((unsigned char)src[i]) || src[i]=='_') i++; add_token(&lexed,T_ID,src+st,i-st,line); continue; }
        if (isdigit((unsigned char)c) || (c=='.' && isdigit((unsigned char)src[i+1]))) { size_t st=i++; while (isdigit((unsigned char)src[i]) || src[i]=='.') i++; add_token(&lexed,T_NUM,src+st,i-st,line); continue; }
        if (c=='"' || c=='\'') {
            char q=c; i++; size_t cap=64,n=0; char *buf=malloc(cap);
            while (src[i] && src[i]!=q) {
                char x=src[i++];
                if (x=='\\' && src[i]) { char e=src[i++]; if(e=='n') x='\n'; else if(e=='t') x='\t'; else if(e=='r') x='\r'; else x=e; }
                if(n+2>cap){cap*=2;buf=realloc(buf,cap);} buf[n++]=x;
            }
            if (src[i]!=q) { fprintf(stderr,"cRevive:%d: unterminated string\n",line); free(buf); return false; }
            i++; buf[n]=0; add_token(&lexed,T_STR,buf,n,line); free(buf); continue;
        }
        const char *two[] = {"**","==","!=",">=","<=","&&","||"}; bool matched=false;
        for(size_t k=0;k<sizeof(two)/sizeof(two[0]);k++) if(src[i]==two[k][0]&&src[i+1]==two[k][1]){add_token(&lexed,T_SYM,src+i,2,line);i+=2;matched=true;break;}
        if(matched) continue;
        if (strchr("(){}[],:=+-*/%><!",c)) { add_token(&lexed,T_SYM,src+i,1,line); i++; continue; }
        fprintf(stderr,"cRevive:%d: unexpected character '%c'\n",line,c); return false;
    }
    add_token(&lexed,T_END,"",0,line); return true;
}
static Token *cur(Parser *p) { return p->pos < p->end ? &p->tokens[p->pos] : &p->tokens[p->end]; }
static bool at(Parser *p,const char *s){return p->pos<p->end && strcmp(cur(p)->text,s)==0;}
static bool type_at(Parser *p,TokType t){return p->pos<p->end && cur(p)->type==t;}
static bool match(Parser *p,const char *s){if(at(p,s)){p->pos++;return true;}return false;}
static void skip_nl(Parser *p){while(p->pos<p->end && cur(p)->type==T_NL)p->pos++;}
static void skip_line(Parser *p){while(p->pos<p->end && cur(p)->type!=T_NL && cur(p)->type!=T_END && strcmp(cur(p)->text,"}")!=0)p->pos++;if(type_at(p,T_NL))p->pos++;}
static void parse_error(Parser *p,const char *msg){int line=cur(p)->line;fprintf(stderr,"cRevive:%d: %s near '%s'\n",line,msg,cur(p)->text);had_error=1;}
static bool expect(Parser *p,const char *s){if(match(p,s))return true;parse_error(p,"expected token");return false;}
static Value env_get(Env *e,const char *name){for(Env *x=e;x;x=x->parent)for(Var *v=x->vars;v;v=v->next)if(strcmp(v->name,name)==0)return v->value;return v_null();}
static void env_set(Env *e,const char *name,Value val){for(Var *v=e->vars;v;v=v->next)if(strcmp(v->name,name)==0){v->value=val;return;}Var *v=calloc(1,sizeof(Var));v->name=strdup(name);v->value=val;v->next=e->vars;e->vars=v;}
static Function *find_func(const char *name){for(size_t i=0;i<function_count;i++)if(strcmp(functions[i].name,name)==0)return &functions[i];return NULL;}
static Flow exec_range(Token *tokens,size_t start,size_t end,Env *env);
static Value parse_expr(Parser *p,int min_prec);
static Value call_function(Parser *p,const char *name,Value *args,int n){
    Function *f=find_func(name); if(!f){fprintf(stderr,"cRevive:%d: unknown function '%s'\n",cur(p)->line,name);had_error=1;return v_null();}
    if(n!=f->param_count){fprintf(stderr,"cRevive: function '%s' expects %d argument(s), got %d\n",name,f->param_count,n);had_error=1;return v_null();}
    Env local={0};local.parent=p->env;for(int i=0;i<n;i++)env_set(&local,f->params[i],args[i]);
    Flow flow=exec_range(p->tokens,f->body_start,f->body_end,&local);return flow.returned?flow.value:v_null();
}
static Value primary(Parser *p){
    if(match(p,"(")){Value v=parse_expr(p,1);expect(p,")");return v;}
    if(match(p,"-")){Value v=primary(p);return v_num(-v.number);}
    if(match(p,"!")){Value v=primary(p);return v_bool(!truthy(v));}
    if(type_at(p,T_NUM)){Value v=v_num(strtod(cur(p)->text,NULL));p->pos++;return v;}
    if(type_at(p,T_STR)){Value v=v_str(cur(p)->text);p->pos++;return v;}
    if(type_at(p,T_ID)){
        char *name=strdup(cur(p)->text);p->pos++;
        if(strcmp(name,"true")==0){free(name);return v_bool(true);}if(strcmp(name,"false")==0){free(name);return v_bool(false);}if(strcmp(name,"null")==0||strcmp(name,"nil")==0){free(name);return v_null();}
        if(match(p,"(")){Value args[64];int n=0;if(!at(p,")")){do{if(n>=64){parse_error(p,"too many function arguments");break;}args[n++]=parse_expr(p,1);}while(match(p,","));}expect(p,")");Value v=call_function(p,name,args,n);free(name);return v;}
        Value v=env_get(p->env,name);free(name);return v;
    }
    parse_error(p,"expected expression");if(p->pos<p->end)p->pos++;return v_null();
}
static int precedence(const char *op){if(!strcmp(op,"||"))return 1;if(!strcmp(op,"&&"))return 2;if(!strcmp(op,"**")||!strcmp(op,"==")||!strcmp(op,"!="))return 3;if(!strcmp(op,">")||!strcmp(op,"<")||!strcmp(op,">=")||!strcmp(op,"<="))return 4;if(!strcmp(op,"+")||!strcmp(op,"-"))return 5;if(!strcmp(op,"*")||!strcmp(op,"/")||!strcmp(op,"%"))return 6;return 0;}
static Value binary(Value a,const char *op,Value b){
    if(!strcmp(op,"||")) return v_bool(truthy(a)||truthy(b));
    if(!strcmp(op,"&&")) return v_bool(truthy(a)&&truthy(b));
    if(!strcmp(op,"**")||!strcmp(op,"==")||!strcmp(op,"!=")){
        bool eq=false;if(a.type==V_NULL||b.type==V_NULL)eq=a.type==b.type;else if(a.type==V_NUM&&b.type==V_NUM)eq=a.number==b.number;else if(a.type==V_BOOL&&b.type==V_BOOL)eq=a.boolean==b.boolean;else {char *x=value_text(a),*y=value_text(b);eq=!strcmp(x,y);free(x);free(y);}return v_bool(!strcmp(op,"!=")?!eq:eq);
    }
    if(!strcmp(op,"+")&&(a.type==V_STR||b.type==V_STR)){char *x=value_text(a),*y=value_text(b);size_t n=strlen(x)+strlen(y)+1;char *z=malloc(n);snprintf(z,n,"%s%s",x,y);Value v=v_str(z);free(x);free(y);free(z);return v;}
    double x=a.type==V_NUM?a.number:(a.type==V_BOOL?(a.boolean?1:0):0),y=b.type==V_NUM?b.number:(b.type==V_BOOL?(b.boolean?1:0):0);
    if(!strcmp(op,"+")) return v_num(x+y);
    if(!strcmp(op,"-")) return v_num(x-y);
    if(!strcmp(op,"*")) return v_num(x*y);
    if(!strcmp(op,"/")){if(y==0){fprintf(stderr,"cRevive: division by zero\n");had_error=1;return v_null();}return v_num(x/y);}
    if(!strcmp(op,"%")) return v_num(fmod(x,y));
    if(!strcmp(op,">")) return v_bool(x>y);
    if(!strcmp(op,"<")) return v_bool(x<y);
    if(!strcmp(op,">=")) return v_bool(x>=y);
    if(!strcmp(op,"<=")) return v_bool(x<=y);
    return v_null();
}
static Value parse_expr(Parser *p,int min_prec){Value left=primary(p);while(p->pos<p->end){const char *op=cur(p)->text;int prec=cur(p)->type==T_SYM?precedence(op):0;if(prec<min_prec||prec==0)break;p->pos++;Value right=parse_expr(p,prec+1);left=binary(left,op,right);}return left;}
static bool block_range(Parser *p,size_t *start,size_t *end){if(!expect(p,"{"))return false;*start=p->pos;int depth=1;while(p->pos<p->end){if(at(p,"{"))depth++;else if(at(p,"}")){depth--;if(depth==0){*end=p->pos;p->pos++;return true;}}p->pos++;}parse_error(p,"unterminated block");return false;}
static Flow exec_range(Token *tokens,size_t start,size_t end,Env *env){
    Parser p={tokens,start,end,env};Flow result={false,v_null()};
    while(p.pos<p.end){skip_nl(&p);if(p.pos>=p.end)break;
        if(type_at(&p,T_ID)&&!strcmp(cur(&p)->text,"import")){p.pos++;if(type_at(&p,T_ID))p.pos++;skip_line(&p);continue;}
        if(type_at(&p,T_ID)&&!strcmp(cur(&p)->text,"say")){p.pos++;Value v=parse_expr(&p,1);char *s=value_text(v);puts(s);free(s);skip_line(&p);continue;}
        if(type_at(&p,T_ID)&&!strcmp(cur(&p)->text,"Postion")){p.pos++;expect(&p,"(");Value sec=parse_expr(&p,1);expect(&p,")");double d=sec.type==V_NUM?sec.number:0;if(d>0&&d<86400){struct timespec ts={(time_t)d,(long)((d-floor(d))*1e9)};nanosleep(&ts,NULL);}skip_line(&p);continue;}
        if(type_at(&p,T_ID)&&!strcmp(cur(&p)->text,"Define")){
            p.pos++;if(!type_at(&p,T_ID)||strcmp(cur(&p)->text,"text")){parse_error(&p,"expected 'text' after Define");break;}p.pos++;expect(&p,"[");if(!type_at(&p,T_ID)){parse_error(&p,"expected function name");break;}char *name=strdup(cur(&p)->text);p.pos++;expect(&p,"]");expect(&p,"=");char *params[64];int n=0;
            if(match(&p,"(")){if(!at(&p,")")){do{if(!type_at(&p,T_ID)||n>=64){parse_error(&p,"invalid function parameter");break;}params[n++]=strdup(cur(&p)->text);p.pos++;}while(match(&p,","));}expect(&p,")");}
            size_t bs=0,be=0;if(!block_range(&p,&bs,&be))break;if(function_count>=MAX_FUNCS){parse_error(&p,"function limit exceeded");break;}Function *f=find_func(name);if(!f)f=&functions[function_count++];else {for(int i=0;i<f->param_count;i++)free(f->params[i]);}
            f->name=name;f->param_count=n;f->params=calloc(n?n:1,sizeof(char*));for(int i=0;i<n;i++)f->params[i]=params[i];f->body_start=bs;f->body_end=be;skip_nl(&p);continue;
        }
        if(type_at(&p,T_ID)&&!strcmp(cur(&p)->text,"Check")){p.pos++;Value cond=parse_expr(&p,1);size_t bs,be;if(!block_range(&p,&bs,&be))break;bool pass=cond.type==V_NULL?true:truthy(cond);if(pass){Flow f=exec_range(tokens,bs,be,env);if(f.returned)return f;}skip_nl(&p);continue;}
        if(type_at(&p,T_ID)&&!strcmp(cur(&p)->text,"Return")){p.pos++;Value v=parse_expr(&p,1);result.returned=true;result.value=v;return result;}
        if(type_at(&p,T_ID)&&!strcmp(cur(&p)->text,"Loop")){p.pos++;expect(&p,"(");Value count=parse_expr(&p,1);expect(&p,")");expect(&p,"=");size_t bs,be;if(!block_range(&p,&bs,&be))break;long n=count.type==V_NUM?(long)count.number:0;if(n<0)n=0;if(n>MAX_LOOP)n=MAX_LOOP;for(long i=0;i<n;i++){Flow f=exec_range(tokens,bs,be,env);if(f.returned)return f;}skip_nl(&p);continue;}
        if(type_at(&p,T_ID)&&!strcmp(cur(&p)->text,"While")){p.pos++;if(!type_at(&p,T_ID)||strcmp(cur(&p)->text,"loop")){parse_error(&p,"expected 'loop' after While");break;}p.pos++;expect(&p,"(");size_t cond_start=p.pos;int depth=0;while(p.pos<p.end){if(at(&p,"("))depth++;if(at(&p,")")){if(depth==0)break;depth--;}p.pos++;}size_t cond_end=p.pos;expect(&p,")");size_t bs,be;if(!block_range(&p,&bs,&be))break;for(int i=0;i<MAX_LOOP;i++){Parser cp={tokens,cond_start,cond_end,env};Value cond=parse_expr(&cp,1);if(!truthy(cond))break;Flow f=exec_range(tokens,bs,be,env);if(f.returned)return f;if(i==MAX_LOOP-1)fprintf(stderr,"cRevive: loop safety limit reached\n");}skip_nl(&p);continue;}
        if(type_at(&p,T_ID)&&p.pos+1<p.end&&strcmp(tokens[p.pos+1].text,"=")==0){char *name=strdup(cur(&p)->text);p.pos+=2;Value v=parse_expr(&p,1);env_set(env,name,v);free(name);skip_line(&p);continue;}
        /* A function call may appear as a standalone statement. */
        if(type_at(&p,T_ID)&&p.pos+1<p.end&&strcmp(tokens[p.pos+1].text,"(")==0){(void)parse_expr(&p,1);skip_line(&p);continue;}
        parse_error(&p,"unknown statement");skip_line(&p);
    }
    return result;
}
static char *read_file(const char *path){FILE *f=fopen(path,"rb");if(!f){fprintf(stderr,"cRevive: cannot open '%s': %s\n",path,strerror(errno));return NULL;}fseek(f,0,SEEK_END);long n=ftell(f);fseek(f,0,SEEK_SET);char *s=malloc((size_t)n+1);if(!s){fclose(f);return NULL;}size_t got=fread(s,1,(size_t)n,f);s[got]=0;fclose(f);return s;}
int main(int argc,char **argv){if(argc<2){fprintf(stderr,"cRevive v0.1 (C reference interpreter)\nUsage: crevive <file.crv>\n");return 2;}char *src=read_file(argv[1]);if(!src)return 2;if(!tokenize(src)){free(src);return 2;}Env global={0};Flow f=exec_range(lexed.v,0,lexed.n-1,&global);(void)f;free(src);return had_error?1:0;}
