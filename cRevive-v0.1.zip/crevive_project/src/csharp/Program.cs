// cRevive v0.1 interpreter in C# (.NET 8)
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;

namespace CRevive;

internal enum TokenKind { Id, Number, String, Symbol, NewLine, End }
internal sealed record Token(TokenKind Kind, string Text, int Line);
internal sealed record FunctionDef(string Name, string[] Parameters, int BodyStart, int BodyEnd);
internal sealed class EnvironmentFrame
{
    public readonly Dictionary<string, object?> Values = new(StringComparer.Ordinal);
    public EnvironmentFrame? Parent;
    public EnvironmentFrame(EnvironmentFrame? parent = null) => Parent = parent;
    public object? Get(string name) => Values.TryGetValue(name, out var v) ? v : Parent?.Get(name);
}
internal sealed record ExecResult(bool Returned, object? Value);

internal static class Lexer
{
    public static List<Token> Scan(string source)
    {
        var result = new List<Token>(); int i = 0, line = 1;
        while (i < source.Length)
        {
            char c = source[i];
            if (c is ' ' or '\t' or '\r') { i++; continue; }
            if (c == '\n') { result.Add(new(TokenKind.NewLine, "\n", line++)); i++; continue; }
            if (c == '~' && i + 1 < source.Length && source[i + 1] == '~')
            { while (i < source.Length && source[i] != '\n') i++; continue; }
            if (char.IsLetter(c) || c == '_')
            { int start = i++; while (i < source.Length && (char.IsLetterOrDigit(source[i]) || source[i] == '_')) i++; result.Add(new(TokenKind.Id, source[start..i], line)); continue; }
            if (char.IsDigit(c) || (c == '.' && i + 1 < source.Length && char.IsDigit(source[i + 1])))
            { int start = i++; while (i < source.Length && (char.IsDigit(source[i]) || source[i] == '.')) i++; result.Add(new(TokenKind.Number, source[start..i], line)); continue; }
            if (c is '"' or '\'')
            {
                char quote = c; i++; var value = new System.Text.StringBuilder();
                while (i < source.Length && source[i] != quote)
                {
                    char x = source[i++];
                    if (x == '\\' && i < source.Length) { char e = source[i++]; x = e switch { 'n' => '\n', 't' => '\t', 'r' => '\r', _ => e }; }
                    value.Append(x);
                }
                if (i >= source.Length) throw new Exception($"cRevive:{line}: unterminated string");
                i++; result.Add(new(TokenKind.String, value.ToString(), line)); continue;
            }
            string? two = i + 1 < source.Length ? source.Substring(i, 2) : null;
            if (two is "**" or "==" or "!=" or ">=" or "<=" or "&&" or "||")
            { result.Add(new(TokenKind.Symbol, two, line)); i += 2; continue; }
            if ("(){}[],:=+-*/%><!".Contains(c)) { result.Add(new(TokenKind.Symbol, c.ToString(), line)); i++; continue; }
            throw new Exception($"cRevive:{line}: unexpected character '{c}'");
        }
        result.Add(new(TokenKind.End, "", line)); return result;
    }
}

internal sealed class Interpreter
{
    private readonly List<Token> tokens;
    private readonly Dictionary<string, FunctionDef> functions;
    private readonly EnvironmentFrame env;
    private int pos, end;
    public Interpreter(List<Token> tokens, Dictionary<string, FunctionDef> functions, EnvironmentFrame env, int start, int end)
    { this.tokens = tokens; this.functions = functions; this.env = env; pos = start; this.end = end; }
    private Token Current => pos < end ? tokens[pos] : tokens[end];
    private bool At(string s) => pos < end && Current.Text == s;
    private bool Is(TokenKind kind) => pos < end && Current.Kind == kind;
    private bool Match(string s) { if (!At(s)) return false; pos++; return true; }
    private bool Expect(string s) { if (Match(s)) return true; Error($"expected '{s}'"); return false; }
    private void Error(string message) => Console.Error.WriteLine($"cRevive:{Current.Line}: {message} near '{Current.Text}'");
    private void SkipNewLines() { while (pos < end && Is(TokenKind.NewLine)) pos++; }
    private void SkipLine() { while (pos < end && !Is(TokenKind.NewLine) && Current.Text != "}") pos++; if (Is(TokenKind.NewLine)) pos++; }
    private static bool Truthy(object? v) => v switch { null => false, bool b => b, double d => d != 0, string s => s.Length > 0, _ => true };
    private static string Text(object? v) => v switch { null => "null", bool b => b ? "true" : "false", double d => d.ToString("G", CultureInfo.InvariantCulture), _ => v.ToString() ?? "null" };
    private static int Prec(string op) => op switch { "||" => 1, "&&" => 2, "**" or "==" or "!=" => 3, ">" or "<" or ">=" or "<=" => 4, "+" or "-" => 5, "*" or "/" or "%" => 6, _ => 0 };
    private object? Primary()
    {
        if (Match("(")) { var v = Expr(1); Expect(")"); return v; }
        if (Match("-")) return -(Convert.ToDouble(Primary() ?? 0, CultureInfo.InvariantCulture));
        if (Match("!")) return !Truthy(Primary());
        if (Is(TokenKind.Number)) { double.TryParse(Current.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out double d); pos++; return d; }
        if (Is(TokenKind.String)) { string s = Current.Text; pos++; return s; }
        if (Is(TokenKind.Id))
        {
            string name = Current.Text; pos++;
            if (name == "true") return true; if (name == "false") return false; if (name is "null" or "nil") return null;
            if (Match("("))
            {
                var args = new List<object?>(); if (!At(")")) { do { args.Add(Expr(1)); } while (Match(",")); }
                Expect(")"); return Call(name, args);
            }
            return env.Get(name);
        }
        Error("expected expression"); if (pos < end) pos++; return null;
    }
    private object? Expr(int minPrec)
    {
        object? left = Primary();
        while (pos < end && Current.Kind == TokenKind.Symbol)
        {
            string op = Current.Text; int p = Prec(op); if (p < minPrec || p == 0) break; pos++;
            object? right = Expr(p + 1); left = Apply(left, op, right);
        }
        return left;
    }
    private static object? Apply(object? a, string op, object? b)
    {
        if (op == "||") return Truthy(a) || Truthy(b); if (op == "&&") return Truthy(a) && Truthy(b);
        if (op is "**" or "==" or "!=") { bool equal = Equals(a, b) || (a is double da && b is double db && da == db); return op == "!=" ? !equal : equal; }
        if (op == "+" && (a is string || b is string)) return Text(a) + Text(b);
        double x = Convert.ToDouble(a ?? 0, CultureInfo.InvariantCulture), y = Convert.ToDouble(b ?? 0, CultureInfo.InvariantCulture);
        return op switch { "+" => x + y, "-" => x - y, "*" => x * y, "/" => y == 0 ? throw new DivideByZeroException("cRevive: division by zero") : x / y, "%" => x % y, ">" => x > y, "<" => x < y, ">=" => x >= y, "<=" => x <= y, _ => null };
    }
    private object? Call(string name, List<object?> args)
    {
        if (!functions.TryGetValue(name, out var fn)) { Console.Error.WriteLine($"cRevive: unknown function '{name}'"); return null; }
        if (args.Count != fn.Parameters.Length) { Console.Error.WriteLine($"cRevive: function '{name}' expects {fn.Parameters.Length} argument(s), got {args.Count}"); return null; }
        var local = new EnvironmentFrame(env); for (int i = 0; i < args.Count; i++) local.Values[fn.Parameters[i]] = args[i];
        var flow = new Interpreter(tokens, functions, local, fn.BodyStart, fn.BodyEnd).Run(); return flow.Returned ? flow.Value : null;
    }
    private (int Start, int End) ReadBlock()
    {
        if (!Expect("{")) return (pos, pos); int start = pos, depth = 1;
        while (pos < end) { if (At("{")) depth++; else if (At("}")) { depth--; if (depth == 0) { int finish = pos++; return (start, finish); } } pos++; }
        Error("unterminated block"); return (start, pos);
    }
    public ExecResult Run()
    {
        while (pos < end)
        {
            SkipNewLines(); if (pos >= end) break;
            if (Is(TokenKind.Id) && Current.Text == "import") { pos++; if (Is(TokenKind.Id)) pos++; SkipLine(); continue; }
            if (Is(TokenKind.Id) && Current.Text == "say") { pos++; Console.WriteLine(Text(Expr(1))); SkipLine(); continue; }
            if (Is(TokenKind.Id) && Current.Text == "Postion") { pos++; Expect("("); object? seconds = Expr(1); Expect(")"); double d = Convert.ToDouble(seconds ?? 0, CultureInfo.InvariantCulture); if (d > 0 && d < 86400) Thread.Sleep(TimeSpan.FromSeconds(d)); SkipLine(); continue; }
            if (Is(TokenKind.Id) && Current.Text == "Define")
            {
                pos++; if (!Is(TokenKind.Id) || Current.Text != "text") { Error("expected 'text' after Define"); break; } pos++;
                Expect("["); if (!Is(TokenKind.Id)) { Error("expected function name"); break; } string name = Current.Text; pos++; Expect("]"); Expect("=");
                var parameters = new List<string>(); if (Match("(")) { if (!At(")")) { do { if (!Is(TokenKind.Id)) { Error("invalid parameter"); break; } parameters.Add(Current.Text); pos++; } while (Match(",")); } Expect(")"); }
                var block = ReadBlock(); functions[name] = new(name, parameters.ToArray(), block.Start, block.End); SkipNewLines(); continue;
            }
            if (Is(TokenKind.Id) && Current.Text == "Check") { pos++; object? condition = Expr(1); var block = ReadBlock(); if (condition is null || Truthy(condition)) { var r = new Interpreter(tokens, functions, env, block.Start, block.End).Run(); if (r.Returned) return r; } SkipNewLines(); continue; }
            if (Is(TokenKind.Id) && Current.Text == "Return") { pos++; return new(true, Expr(1)); }
            if (Is(TokenKind.Id) && Current.Text == "Loop") { pos++; Expect("("); object? count = Expr(1); Expect(")"); Expect("="); var block = ReadBlock(); int n = Math.Clamp((int)Convert.ToDouble(count ?? 0, CultureInfo.InvariantCulture), 0, 100000); for (int i = 0; i < n; i++) { var r = new Interpreter(tokens, functions, env, block.Start, block.End).Run(); if (r.Returned) return r; } SkipNewLines(); continue; }
            if (Is(TokenKind.Id) && Current.Text == "While")
            {
                pos++; if (!Is(TokenKind.Id) || Current.Text != "loop") { Error("expected 'loop' after While"); break; } pos++; Expect("("); int cs = pos, depth = 0;
                while (pos < end) { if (At("(")) depth++; if (At(")")) { if (depth == 0) break; depth--; } pos++; } int ce = pos; Expect(")"); var block = ReadBlock();
                for (int i = 0; i < 100000; i++) { object? cond = new Interpreter(tokens, functions, env, cs, ce).ExprPublic(); if (!Truthy(cond)) break; var r = new Interpreter(tokens, functions, env, block.Start, block.End).Run(); if (r.Returned) return r; }
                SkipNewLines(); continue;
            }
            if (Is(TokenKind.Id) && pos + 1 < end && tokens[pos + 1].Text == "=") { string name = Current.Text; pos += 2; env.Values[name] = Expr(1); SkipLine(); continue; }
            if (Is(TokenKind.Id) && pos + 1 < end && tokens[pos + 1].Text == "(") { _ = Expr(1); SkipLine(); continue; }
            Error("unknown statement"); SkipLine();
        }
        return new(false, null);
    }
    private object? ExprPublic() => Expr(1);
}

internal static class Program
{
    public static int Main(string[] args)
    {
        if (args.Length == 0) { Console.WriteLine("cRevive v0.1 (C# interpreter)\nUsage: crevive <file.crv>"); return 2; }
        try { string source = File.ReadAllText(args[0]); var tokens = Lexer.Scan(source); var functions = new Dictionary<string, FunctionDef>(StringComparer.Ordinal); var env = new EnvironmentFrame(); new Interpreter(tokens, functions, env, 0, tokens.Count - 1).Run(); return 0; }
        catch (Exception ex) { Console.Error.WriteLine(ex.Message); return 1; }
    }
}
