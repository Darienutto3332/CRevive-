//! cRevive v0.1 interpreter in Rust.
use std::cell::RefCell;
use std::collections::HashMap;
use std::env;
use std::fs;
use std::rc::Rc;
use std::thread;
use std::time::Duration;

#[derive(Clone, Copy, Debug, PartialEq)]
enum Kind { Id, Number, String, Symbol, NewLine, End }
#[derive(Clone, Debug)]
struct Token { kind: Kind, text: String, line: usize }
#[derive(Clone, Debug, PartialEq)]
enum Value { Null, Number(f64), Bool(bool), String(String) }
impl Value {
    fn truthy(&self) -> bool { match self { Value::Null => false, Value::Bool(b) => *b, Value::Number(n) => *n != 0.0, Value::String(s) => !s.is_empty() } }
    fn text(&self) -> String { match self { Value::Null => "null".into(), Value::Bool(b) => b.to_string(), Value::Number(n) => { let mut s = format!("{}", n); if s.ends_with(".0") { s.truncate(s.len()-2); } s }, Value::String(s) => s.clone() } }
    fn number(&self) -> f64 { match self { Value::Number(n) => *n, Value::Bool(b) => if *b {1.0} else {0.0}, _ => 0.0 } }
}
#[derive(Default)]
struct Environment { values: HashMap<String, Value>, parent: Option<Rc<RefCell<Environment>>> }
impl Environment {
    fn get(&self, name: &str) -> Value { if let Some(v) = self.values.get(name) { return v.clone(); } if let Some(p) = &self.parent { return p.borrow().get(name); } Value::Null }
    fn set(&mut self, name: String, value: Value) { self.values.insert(name, value); }
}
#[derive(Clone)]
struct FunctionDef { params: Vec<String>, start: usize, end: usize }
#[derive(Clone)]
struct Flow { returned: bool, value: Value }

fn tokenize(source: &str) -> Result<Vec<Token>, String> {
    let c: Vec<char> = source.chars().collect(); let mut out = Vec::new(); let mut i = 0usize; let mut line = 1usize;
    while i < c.len() {
        let ch = c[i];
        if ch == ' ' || ch == '\t' || ch == '\r' { i += 1; continue; }
        if ch == '\n' { out.push(Token { kind: Kind::NewLine, text: "\n".into(), line }); line += 1; i += 1; continue; }
        if ch == '~' && i+1 < c.len() && c[i+1] == '~' { while i < c.len() && c[i] != '\n' { i += 1; } continue; }
        if ch.is_ascii_alphabetic() || ch == '_' { let st=i; i+=1; while i<c.len() && (c[i].is_ascii_alphanumeric()||c[i]=='_') {i+=1;} out.push(Token{kind:Kind::Id,text:c[st..i].iter().collect(),line});continue; }
        if ch.is_ascii_digit() || (ch=='.' && i+1<c.len() && c[i+1].is_ascii_digit()) { let st=i;i+=1;while i<c.len()&&(c[i].is_ascii_digit()||c[i]=='.'){i+=1;}out.push(Token{kind:Kind::Number,text:c[st..i].iter().collect(),line});continue; }
        if ch=='"' || ch=='\'' { let quote=ch;i+=1;let mut s=String::new();while i<c.len()&&c[i]!=quote{let mut x=c[i];i+=1;if x=='\\'&&i<c.len(){let e=c[i];i+=1;x=match e{'n'=>'\n','t'=>'\t','r'=>'\r',_=>e};}s.push(x);}if i>=c.len(){return Err(format!("cRevive:{}: unterminated string",line));}i+=1;out.push(Token{kind:Kind::String,text:s,line});continue; }
        if i+1<c.len(){let two:String=c[i..i+2].iter().collect();if ["**","==","!=",">=","<=","&&","||"].contains(&two.as_str()){out.push(Token{kind:Kind::Symbol,text:two,line});i+=2;continue;}}
        if "(){}[],:=+-*/%><!".contains(ch){out.push(Token{kind:Kind::Symbol,text:ch.to_string(),line});i+=1;continue;}
        return Err(format!("cRevive:{}: unexpected character '{}'",line,ch));
    }
    out.push(Token{kind:Kind::End,text:String::new(),line});Ok(out)
}

struct Parser { tokens: Rc<Vec<Token>>, pos: usize, end: usize, env: Rc<RefCell<Environment>>, funcs: Rc<RefCell<HashMap<String,FunctionDef>>> }
impl Parser {
    fn new(tokens: Rc<Vec<Token>>, start: usize, end: usize, env: Rc<RefCell<Environment>>, funcs: Rc<RefCell<HashMap<String,FunctionDef>>>) -> Self { Self{tokens,pos:start,end,env,funcs} }
    fn cur(&self)->&Token { if self.pos<self.end {&self.tokens[self.pos]} else {&self.tokens[self.end]} }
    fn at(&self,s:&str)->bool {self.pos<self.end&&self.cur().text==s}
    fn is(&self,k:Kind)->bool {self.pos<self.end&&self.cur().kind==k}
    fn take(&mut self,s:&str)->bool {if self.at(s){self.pos+=1;true}else{false}}
    fn expect(&mut self,s:&str){if !self.take(s){eprintln!("cRevive:{}: expected '{}' near '{}'",self.cur().line,s,self.cur().text);}}
    fn skip_nl(&mut self){while self.pos<self.end&&self.is(Kind::NewLine){self.pos+=1;}}
    fn skip_line(&mut self){while self.pos<self.end&&!self.is(Kind::NewLine)&&!self.at("}"){self.pos+=1;}if self.is(Kind::NewLine){self.pos+=1;}}
    fn prec(op:&str)->u8{match op{"||"=>1,"&&"=>2,"**"|"=="|"!="=>3,">"|"<"|">="|"<="=>4,"+"|"-"=>5,"*"|"/"|"%"=>6,_=>0}}
    fn primary(&mut self)->Value {
        if self.take("("){let v=self.expr(1);self.expect(")");return v;}
        if self.take("-"){return Value::Number(-self.primary().number());}
        if self.take("!"){return Value::Bool(!self.primary().truthy());}
        if self.is(Kind::Number){let v=self.cur().text.parse::<f64>().unwrap_or(0.0);self.pos+=1;return Value::Number(v);}
        if self.is(Kind::String){let v=self.cur().text.clone();self.pos+=1;return Value::String(v);}
        if self.is(Kind::Id){let name=self.cur().text.clone();self.pos+=1;match name.as_str(){"true"=>return Value::Bool(true),"false"=>return Value::Bool(false),"null"|"nil"=>return Value::Null,_=>{}}
            if self.take("("){let mut args=Vec::new();if !self.at(")"){loop{args.push(self.expr(1));if !self.take(","){break;}}}self.expect(")");return self.call(&name,args);}
            return self.env.borrow().get(&name);
        }
        eprintln!("cRevive:{}: expected expression near '{}'",self.cur().line,self.cur().text);if self.pos<self.end{self.pos+=1;}Value::Null
    }
    fn expr(&mut self,min:u8)->Value{let mut left=self.primary();while self.pos<self.end&&self.is(Kind::Symbol){let op=self.cur().text.clone();let p=Self::prec(&op);if p<min||p==0{break;}self.pos+=1;let right=self.expr(p+1);left=Self::apply(left,&op,right);}left}
    fn apply(a:Value,op:&str,b:Value)->Value{
        match op{"||"=>return Value::Bool(a.truthy()||b.truthy()),"&&"=>return Value::Bool(a.truthy()&&b.truthy()),"**"|"=="=>return Value::Bool(a==b),"!="=>return Value::Bool(a!=b),"+" if matches!(&a,Value::String(_))||matches!(&b,Value::String(_))=>return Value::String(format!("{}{}",a.text(),b.text())),_=>{}}
        let x=a.number();let y=b.number();match op{"+"=>Value::Number(x+y),"-"=>Value::Number(x-y),"*"=>Value::Number(x*y),"/"=>if y==0.0{eprintln!("cRevive: division by zero");Value::Null}else{Value::Number(x/y)},"%"=>Value::Number(x%y),">"=>Value::Bool(x>y),"<"=>Value::Bool(x<y),">="=>Value::Bool(x>=y),"<="=>Value::Bool(x<=y),_=>Value::Null}
    }
    fn call(&mut self,name:&str,args:Vec<Value>)->Value{
        let Some(f)=self.funcs.borrow().get(name).cloned() else{eprintln!("cRevive: unknown function '{}'",name);return Value::Null;};
        if args.len()!=f.params.len(){eprintln!("cRevive: function '{}' expects {} argument(s), got {}",name,f.params.len(),args.len());return Value::Null;}
        let local=Rc::new(RefCell::new(Environment{values:HashMap::new(),parent:Some(self.env.clone())}));for (p,v) in f.params.iter().zip(args){local.borrow_mut().set(p.clone(),v);}
        let mut sub=Parser::new(self.tokens.clone(),f.start,f.end,local,self.funcs.clone());let flow=sub.run();if flow.returned{flow.value}else{Value::Null}
    }
    fn block(&mut self)->(usize,usize){self.expect("{");let start=self.pos;let mut depth=1i32;while self.pos<self.end{if self.at("{"){depth+=1;}else if self.at("}"){depth-=1;if depth==0{let finish=self.pos;self.pos+=1;return(start,finish);}}self.pos+=1;}eprintln!("cRevive: unterminated block");(start,self.pos)}
    fn subrun(&self,start:usize,end:usize)->Flow{let mut p=Parser::new(self.tokens.clone(),start,end,self.env.clone(),self.funcs.clone());p.run()}
    fn run(&mut self)->Flow{
        while self.pos<self.end{self.skip_nl();if self.pos>=self.end{break;}
            if self.is(Kind::Id)&&self.cur().text=="import"{self.pos+=1;if self.is(Kind::Id){self.pos+=1;}self.skip_line();continue;}
            if self.is(Kind::Id)&&self.cur().text=="say"{self.pos+=1;println!("{}",self.expr(1).text());self.skip_line();continue;}
            if self.is(Kind::Id)&&self.cur().text=="Postion"{self.pos+=1;self.expect("(");let sec=self.expr(1).number();self.expect(")");if sec>0.0&&sec<86400.0{thread::sleep(Duration::from_secs_f64(sec));}self.skip_line();continue;}
            if self.is(Kind::Id)&&self.cur().text=="Define"{self.pos+=1;if !self.is(Kind::Id)||self.cur().text!="text"{eprintln!("cRevive: expected 'text' after Define");break;}self.pos+=1;self.expect("[");let name=self.cur().text.clone();self.pos+=1;self.expect("]");self.expect("=");let mut params=Vec::new();if self.take("("){if !self.at(")"){loop{if !self.is(Kind::Id){eprintln!("cRevive: invalid function parameter");break;}params.push(self.cur().text.clone());self.pos+=1;if !self.take(","){break;}}}self.expect(")");}let(s,e)=self.block();self.funcs.borrow_mut().insert(name,FunctionDef{params,start:s,end:e});self.skip_nl();continue;}
            if self.is(Kind::Id)&&self.cur().text=="Check"{self.pos+=1;let cond=self.expr(1);let(s,e)=self.block();if cond==Value::Null||cond.truthy(){let f=self.subrun(s,e);if f.returned{return f;}}self.skip_nl();continue;}
            if self.is(Kind::Id)&&self.cur().text=="Return"{self.pos+=1;return Flow{returned:true,value:self.expr(1)};}
            if self.is(Kind::Id)&&self.cur().text=="Loop"{self.pos+=1;self.expect("(");let count=self.expr(1).number() as i64;self.expect(")");self.expect("=");let(s,e)=self.block();for _ in 0..count.clamp(0,100000){let f=self.subrun(s,e);if f.returned{return f;}}self.skip_nl();continue;}
            if self.is(Kind::Id)&&self.cur().text=="While"{self.pos+=1;if !self.is(Kind::Id)||self.cur().text!="loop"{eprintln!("cRevive: expected 'loop' after While");break;}self.pos+=1;self.expect("(");let cs=self.pos;let mut depth=0i32;while self.pos<self.end{if self.at("("){depth+=1;}if self.at(")"){if depth==0{break;}depth-=1;}self.pos+=1;}let ce=self.pos;self.expect(")");let(s,e)=self.block();for _ in 0..100000{let mut cp=Parser::new(self.tokens.clone(),cs,ce,self.env.clone(),self.funcs.clone());if !cp.expr(1).truthy(){break;}let f=self.subrun(s,e);if f.returned{return f;}}self.skip_nl();continue;}
            if self.is(Kind::Id)&&self.pos+1<self.end&&self.tokens[self.pos+1].text=="="{let name=self.cur().text.clone();self.pos+=2;let v=self.expr(1);self.env.borrow_mut().set(name,v);self.skip_line();continue;}
            if self.is(Kind::Id)&&self.pos+1<self.end&&self.tokens[self.pos+1].text=="("{let _=self.expr(1);self.skip_line();continue;}
            eprintln!("cRevive:{}: unknown statement near '{}'",self.cur().line,self.cur().text);self.skip_line();
        }
        Flow{returned:false,value:Value::Null}
    }
}
fn main(){let args:Vec<String>=env::args().collect();if args.len()<2{println!("cRevive v0.1 (Rust interpreter)\nUsage: crevive <file.crv>");return;}let src=match fs::read_to_string(&args[1]){Ok(s)=>s,Err(e)=>{eprintln!("cRevive: {}",e);std::process::exit(2);}};let tokens=match tokenize(&src){Ok(t)=>Rc::new(t),Err(e)=>{eprintln!("{}",e);std::process::exit(1);}};let funcs=Rc::new(RefCell::new(HashMap::new()));let root=Rc::new(RefCell::new(Environment::default()));let mut parser=Parser::new(tokens.clone(),0,tokens.len()-1,root,funcs);let _=parser.run();}
