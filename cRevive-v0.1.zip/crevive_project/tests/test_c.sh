#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
./crevive-c examples/hello.crv > tests/actual_hello.txt
if ! diff -u tests/expected_hello.txt tests/actual_hello.txt; then
  echo "C interpreter test failed" >&2
  exit 1
fi
./crevive-c examples/functions.crv > tests/actual_functions.txt
grep -F "20 + 22 = 42" tests/actual_functions.txt >/dev/null
echo "C interpreter tests passed"
